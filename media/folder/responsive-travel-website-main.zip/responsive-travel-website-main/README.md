# Responsive Travel Website 🌊
## [Watch it on youtube](https://youtu.be/YzRDHxbw1RU)
###  Responsive Travel Website 🌊

- Travel website to the most beautiful beaches, using HTML, CSS & JAVASCRIPT.
- Contains animations when scrolling.
- Includes a dark and light mode.
- Developed first with the Mobile First methodology, then for desktop.
- Compatible with all mobile devices and with a beautiful and pleasant user interface.

Join the channel to see more videos like this. [Bedimcode](https://www.youtube.com/c/Bedimcode)

![travel-website](/preview.png)
